import React from "react"
import {Text, View, StyleSheet} from 'react-native'
// import Primeiro from './componentes/Primeiro'
// import Of, {Comp1,Comp2} from './componentes/MultiplosComponentes'
// import MinMax from "./componentes/MinMax"
// import Aleatorio from "./componentes/Aleatorio"
import Titulo from "./componentes/Titulo"



export default () => (
    <View style={styles.TelaIniciante}>
        <Titulo principal="Cadastro Produto" 
                secundario="Tela de Cadastro"/>
        {/* <Primeiro/>
        <Text >1 + 2</Text>
        <Text>O Valor da soma 1 + 2 = {1+2}</Text>
        <Comp1/>
        <Comp2/>
        <Of/> 
         <MinMax min="3" max="20"/>
        <MinMax min="5" max="40"/>
        <MinMax min="7" max="55"/>
         <Aleatorio min={4} max={60}/> */}
    </View>
)


// export default App

const styles = StyleSheet.create({
    TelaIniciante: {
        flexGrow: 1,
        justifyContent: "center",
        alignItems: 'center',
        padding: 20
    }
})

// Lista de comentarios

// function App(){
//     const jsx = <Text>Felipe Ribeiro</Text>
//     return jsx
// }

// const App = function () {
//     return <Text>Component 2</Text>
// }

// export default function() {
//     return <Text>Component 3</Text>
// }

// export default () => {
//     return <Text>Component 4</Text>
// }